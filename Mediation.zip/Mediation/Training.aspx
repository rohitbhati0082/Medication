﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Training.aspx.cs" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="https://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8">
	 <meta name="keywords" content="website designing and development, web development, mobile app development, software development, school management software, website development"></meta>
    <meta name="description" content="meet solution provides website and software development services in delhi/ncr, india."></meta>

  <title>Website Design Comppany in Delhi,Best Website Designer in Delhi NCR,Software Development Company in India</title>
  <link rel="shortcut icon" href="img/favicon.ico" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="css/font-min.css" rel="stylesheet" />
<!-- bxslider -->
<link type="text/css" rel='stylesheet' href="js/bxslider/jquery.bxslider.css" />
<!-- End bxslider -->
<!-- flexslider -->
<link type="text/css" rel='stylesheet' href="js/flexslider/flexslider.css" />
<!-- End flexslider -->

<!-- bxslider -->
<link type="text/css" rel='stylesheet' href="js/radial-progress/style.css" />
<!-- End bxslider -->

<!-- Animate css -->
<link type="text/css" rel='stylesheet' href="css/animate.css" />
<!-- End Animate css -->

<!-- Bootstrap css -->
<link type="text/css" rel='stylesheet' href="css/bootstrap.min.css" />
<link type="text/css" rel='stylesheet' href="js/bootstrap-progressbar/bootstrap-progressbar-3.2.0.min.css" />
<!-- End Bootstrap css -->

<!-- Jquery UI css -->
<link type="text/css" rel='stylesheet' href="js/jqueryui/jquery-ui.css" />
<link type="text/css" rel='stylesheet' href="js/jqueryui/jquery-ui.structure.css" />
<!-- End Jquery UI css -->

<!-- Fancybox -->
<link type="text/css" rel='stylesheet' href="js/fancybox/jquery.fancybox.css" />
<!-- End Fancybox -->

<link type="text/css" rel='stylesheet' href="fonts/fonts.css" />
<link href="css/abc.css" rel='stylesheet' type='text/css'>
<link href="css/abc1.css" rel='stylesheet' type='text/css'>

<link type="text/css" data-themecolor="default" rel='stylesheet' href="css/main-default.css" />

<link type="text/css" rel='stylesheet' href="js/rs-plugin/css/settings.css" />
<link type="text/css" rel='stylesheet' href="js/rs-plugin/css/settings-custom.css" />
<link type="text/css" rel='stylesheet' href="js/rs-plugin/videojs/video-js.css" />
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script type="text/javascript"> 
<!--
    //Disable right click script  
    var message = "Sorry, right-click has been disabled";
    /////////////////////////////////// 
    function clickIE() { if (document.all) { (message); return false; } }
    function clickNS(e) {
        if
(document.layers || (document.getElementById && !document.all)) {
            if (e.which == 2 || e.which == 3) { (message); return false; }
        }
    }
    if (document.layers)
    { document.captureEvents(Event.MOUSEDOWN); document.onmousedown = clickNS; }
    else { document.onmouseup = clickNS; document.oncontextmenu = clickIE; }
    document.oncontextmenu = new Function("return false") 
// --> 
</script>
</head>
<body style="width:96%; margin-left: 2%; padding-top: 0px; background-image:url(img/newback.jpg);">

    <form id="form1" runat="server">
    <div class="mask-l" style="background-color: #fff; width: 100%; height: 100%; position: fixed; top: 0; left:0; z-index: 9999999;"></div> <!--removed by integration-->
<header>
  <div class="container b-header__box b-relative">
  <div style="float:right;" id="google_translate_element"></div><script type="text/javascript">
                                                                    function googleTranslateElementInit() {
                                                                        new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
                                                                    }
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
  
   <h2 style="color:Red;font-weight:bold; float:right; margin-right:50px;">Grow your business with Meet Solution</h2> 
  <h2 style="color:Blue;font-weight:bold; float:right; margin-right:50px;">WhatsApp @  +91-8595780082</h2> 
    <a href="#" class="b-left b-logo "><img class="color-theme" data-retina src="img/logo-header-default.png" alt="Logo" /></a>    
          <div class="b-top-nav-show-slide f-top-nav-show-slide b-right j-top-nav-show-slide">MENU</div>
      <nav class="b-top-nav f-top-nav b-right j-top-nav">
          <ul class="b-top-nav__1level_wrap">
             <li class="b-top-nav__1level f-top-nav__1level is-active-top-nav__1level f-primary-b"><a href="Contactus.aspx"><i class="fa fa-home b-menu-1level-ico"></i>MLM Software Demo <span class="b-ico-dropdown"></span></a>
      
    </li>
     <li class="b-top-nav__1level f-top-nav__1level f-primary-b">
        <a href="Default.aspx"><i class="fa fa-folder-open b-menu-1level-ico"></i>Home<span class="b-ico-dropdown"></span></a>
       
    </li>
     <li class="b-top-nav__1level f-top-nav__1level f-primary-b">
        <a href="Aboutus.aspx"><i class="fa fa-folder-open b-menu-1level-ico"></i>About Us<span class="b-ico-dropdown"></span></a>
       
    </li>
    
    </li>
  
    <li class="b-top-nav__1level f-top-nav__1level f-primary-b">
        <a href="#"><i class="fa fa-picture-o b-menu-1level-ico"></i>Our Services <span class="b-ico-dropdown"><img src="img/images.png" style="height:20px;" /></span></a>
        <div class="b-top-nav__dropdomn">
            <ul class="b-top-nav__2level_wrap">
                <li class="b-top-nav__2level_title f-top-nav__2level_title">MEET SOLUTION</li>
                <li class="b-top-nav__2level f-top-nav__2level f-primary"><a href="#">Website Designing</a></li>
                <li data-box-id="0" class="b-top-nav__2level f-top-nav__2level f-primary b-top-nav__with-multi-lvl"><a onclick="return false" href="#">Software Development</a>
                    
                </li>
                <li data-box-id="1" class="b-top-nav__2level f-top-nav__2level f-primary b-top-nav__with-multi-lvl"><a onclick="return false" href="#">Online Test Practice Software</a>
                   
                </li>
                <li class="b-top-nav__2level f-top-nav__2level f-primary b-top-nav__with-multi-lvl"><a onclick="return false" href="#">ERP Software Development</a>
                   
                </li>
                <li class="b-top-nav__2level f-top-nav__2level f-primary b-top-nav__with-multi-lvl"><a onclick="return false" href="#">Digital Marketing</a>
                  
                </li>
                <li class="b-top-nav__2level f-top-nav__2level f-primary"><a href="#">E-Commerce Websites</a></li>
           
            <li class="b-top-nav__2level f-top-nav__2level f-primary"><a href="#">Mobile App Development</a></li>
             <li class="b-top-nav__2level f-top-nav__2level f-primary"><a href="#">IT-Training</a></li>
              <li class="b-top-nav__2level f-top-nav__2level f-primary"><a href="#">Customised Web Applications</a></li>


           
            </ul>
        </div>
    </li>
    <li class="b-top-nav__1level f-top-nav__1level is-active-top-nav__1level f-primary-b">
        <a href="Training.aspx"><i class="fa fa-code b-menu-1level-ico"></i>IT-Training<span class="b-ico-dropdown"><img src="img/images.png" style="height:20px;" /></span></a>
        
    </li>


   
   
   
    <li class="b-top-nav__1level f-top-nav__1level f-primary-b">
        <a href="Career.aspx"><i class="fa fa-folder-open b-menu-1level-ico"></i>Career<span class="b-ico-dropdown"></span></a>
      
    </li>


   
    <li class="b-top-nav__1level f-top-nav__1level f-primary-b"><a href="Contactus.aspx">Contact Us <span class="b-ico-dropdown"></span></a>
      
</ul>

      </nav>
    </div>
 
</header>
<div class="j-menu-container"></div>


  <div class="l-main-container">
  
  <img src="img/training.jpg" style="width:100%;" />

<section class="b-bg-full-primary">
  <div class="container">
    <div class="b-categories-icons">
      <div class="b-categories-icons__item f-categories-icons__item b-column">
        <a class="b-categories-icons__item_link">
          <div class="b-categories-icons__item_icon f-categories-icons__item_icon fade-in-animate">
          
          </div>
          <div class="b-remaining b-categories-icons__item_text">
            <div class="b-categories-icons__item_name f-categories-icons__item_name f-secondary-b">Website Development</div>
            <div class="b-categories-icons__item_info f-categories-icons__item_info f-secondary-l">we have developed websites for indian as well as out of india customers</div>
          </div>
        </a>
      </div>
      <div class="b-categories-icons__item f-categories-icons__item b-column">
        <a class="b-categories-icons__item_link">
          <div class="b-categories-icons__item_icon f-categories-icons__item_icon fade-in-animate">
           
          </div>
          <div class="b-remaining b-categories-icons__item_text">
            <div class="b-categories-icons__item_name f-categories-icons__item_name f-secondary-b">Software Development</div>
            <div class="b-categories-icons__item_info f-categories-icons__item_info f-secondary-l">we have developed many web softwares for industries</div>
          </div>
        </a>
      </div>
      <div class="b-categories-icons__item f-categories-icons__item b-column">
        <a class="b-categories-icons__item_link" >
          <div class="b-categories-icons__item_icon f-categories-icons__item_icon fade-in-animate">
          
          </div>
          <div class="b-remaining b-categories-icons__item_text">
            <div class="b-categories-icons__item_name f-categories-icons__item_name f-secondary-b">Ecommerce Websites </div>
            <div class="b-categories-icons__item_info f-categories-icons__item_info f-secondary-l">we have developed many ecommerce websites </div>
          </div>
        </a>
      </div>
      <div class="b-categories-icons__item f-categories-icons__item b-column">
        <a class="b-categories-icons__item_link">
          <div class="b-categories-icons__item_icon f-categories-icons__item_icon fade-in-animate">
          
          </div>
          <div class="b-remaining b-categories-icons__item_text">
            <div class="b-categories-icons__item_name f-categories-icons__item_name f-secondary-b">Digital Marketing</div>
            <div class="b-categories-icons__item_info f-categories-icons__item_info f-secondary-l">we provide digital marketing for many customers</div>
          </div>
        </a>
      </div>
      <div class="b-categories-icons__item f-categories-icons__item b-column">
        <a class="b-categories-icons__item_link" >
          <div class="b-categories-icons__item_icon f-categories-icons__item_icon fade-in-animate">
          
          </div>
          <div class="b-remaining b-categories-icons__item_text">
            <div class="b-categories-icons__item_name f-categories-icons__item_name f-secondary-b">Software Sales</div>
            <div class="b-categories-icons__item_info f-categories-icons__item_info f-secondary-l">we have sold many softwares for schools and institutes </div>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>



    
<div class="l-main-container">


 <div class="b-desc-section-container">
        <section class="container b-welcome-box">
            <div class="row">
                <div class="col-md-offset-2 col-md-8">
                    <h2 class="is-global-title f-center f-legacy-h1" style="text-align:justify;"><b>Career with Meet Solution - We provide live project based IT-Training for those students who really wants to develop their career in the field of IT.</b></h2>
                    <p class="f-center" style="font-size:15px;"><b></b> </p>
                    <p style="font-size:15px; width:100%;">
                 <b>Training with MEET SOLUTION to get 100% job in IT-Field.</b>
                </p>
                </div>
            </div>
        </section>
        <section class="container">
            <div class="row">
                <div class="col-sm-6 b-contact-form-box">
                    <h3 class="f-legacy-h3 f-primary-b b-title-description f-title-description">
                     Please fill the form to get trainig for job in IT...   <asp:Label ID="Label1" runat="server" Text="" ForeColor="Red" Font-Size="12px"></asp:Label>
                                         </h3>
                    <div class="row">
                      
                            <div class="col-md-6">
                                <div class="b-form-row">
                                    <label class="b-form-vertical__label" for="name"><b>Your name</b></label>
                                    <div class="b-form-vertical__input">
                                    <asp:TextBox ID="TextBox1" runat="server" class="form-control" ></asp:TextBox>
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="Please Enter Your Name" ForeColor="Red" ControlToValidate="TextBox1"></asp:RequiredFieldValidator>
                                      
                                    </div>
                                </div>
                                <div class="b-form-row">
                                    <label class="b-form-vertical__label" for="email"><b>Phone No.</b></label>
                                    <div class="b-form-vertical__input">
                                      
                                        <asp:TextBox ID="TextBox2" runat="server" class="form-control"></asp:TextBox>
                                        <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ErrorMessage="Please enter your phone no." ControlToValidate="TextBox2"></asp:RequiredFieldValidator>
                                         <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server"  
ControlToValidate="TextBox2" ErrorMessage="Enter correct phone number" ForeColor="Red"  
ValidationExpression="[0-9]{10}"></asp:RegularExpressionValidator>  
                                    </div>
                                </div>
                                <div class="b-form-row">
                                    <label class="b-form-vertical__label" for="website"><b>Email</b></label>
                                    <div class="b-form-vertical__input">
                                       <asp:TextBox ID="TextBox3" runat="server" class="form-control"></asp:TextBox>
                                    </div>
                                </div>
                                <div class="b-form-row">
                                    <label class="b-form-vertical__label" for="title"><b>Qualification</b></label><br />
                                    <div class="b-form-vertical__input">
                                       <asp:DropDownList ID="DropDownList1" runat="server">
                                        <asp:ListItem>Please Select</asp:ListItem>
                                       <asp:ListItem>BCA</asp:ListItem>
                                        <asp:ListItem>MCA</asp:ListItem>
                                         <asp:ListItem>BSC-IT</asp:ListItem>
                                          <asp:ListItem>B-Voc</asp:ListItem>
                                           <asp:ListItem>Other</asp:ListItem>
                                             <asp:ListItem>B-Tech-CS</asp:ListItem>
                                              <asp:ListItem>12th</asp:ListItem>
                                               <asp:ListItem>other</asp:ListItem>
                                       </asp:DropDownList>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="b-form-row b-form--contact-size">
                                    <label class="b-form-vertical__label">Where do you want to
see yourself after 1 year</label>
                                    <asp:TextBox ID="TextBox4" class="form-control" runat="server" TextMode="MultiLine" Rows="5"></asp:TextBox>
                                   
                                </div>
                                <div class="b-form-row">
<!-- Honeypot (Hidden Field) -->
    <asp:TextBox ID="txtWebsite" runat="server" Style="display:none;"></asp:TextBox>

    <!-- Google reCAPTCHA -->
    <div class="g-recaptcha" data-sitekey="6Le9NE8sAAAAAOW8Yf1ejGh0Dl9TU-1RQ5XKfNnc"></div><br />
                                   <asp:Button ID="Button1" runat="server" Text="Submit" 
                                        class="b-btn f-btn b-btn-md b-btn-default f-primary-b b-btn__w100" 
                                        onclick="Button1_Click"></asp:Button>
                                </div>
                            </div>
                   
                    </div>
                </div>
                <div class="col-sm-6 b-contact-form-box">
                    <h3 class="f-legacy-h3 f-primary-b b-title-description f-title-description">
                      <p>NOTE: <br />1. <b style="color:Black;">BCA, MCA, B-Voc, B.Sc IT, B-Tech and those students who want to make career in IT field can fill this form with registration of 100 INR. This amount would be mange in your first installment.</b></p>
			  
			    <p>2. <b style="color:Black;"> First we are not Institute, we are an IT comapany that deals in Software Development, Website Development, and many other online modules. </b></p>
			  <p><b style="color:Black;"> Our selection process for training is simple ' FIRST COME FIRST SERVE ' So students get ready to get sucess in your life.</b></p>
          </h3>
                    
                </div>
            </div>

         

        </section>
    </div>
   


</div>





</div>

  <footer>
  <div class="b-footer-primary">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-xs-12 f-copyright b-copyright">Copyright © 2010-2019 - All Rights Reserved | Meetsolution.com</div>
            <div class="col-sm-8 col-xs-12">
                <div class="b-btn f-btn b-btn-default b-right b-footer__btn_up f-footer__btn_up j-footer__btn_up">
                    <i class="fa fa-chevron-up"></i>
                </div>
                <nav class="b-bottom-nav f-bottom-nav b-right hidden-xs">
                   <img src="img/donotcopy.png" /> &nbsp;&nbsp;&nbsp;&nbsp;Website Design By: <a href="https://www.meetsolution.com" target="_blank">MEET SOLUTION</a>
                   <br />
                </nav>
            </div>
        </div>
    </div>
</div>
  
</footer>
<script src="js/JScript.js"></script>
<script src="js/jquery/jquery-1.11.1.min.js"></script>
<!-- bootstrap -->
<script src="js/scrollspy.js"></script>
<script src="js/bootstrap-progressbar/bootstrap-progressbar.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- end bootstrap -->
<script src="js/masonry.pkgd.min.js"></script>
<script src='js/imagesloaded.pkgd.min.js'></script>
<!-- bxslider -->
<script src="js/bxslider/jquery.bxslider.min.js"></script>
<!-- end bxslider -->
<!-- flexslider -->
<script src="js/flexslider/jquery.flexslider.js"></script>
<!-- end flexslider -->
<!-- smooth-scroll -->
<script src="js/smooth-scroll/SmoothScroll.js"></script>
<!-- end smooth-scroll -->
<!-- carousel -->
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<!-- end carousel -->
<script src="js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script src="js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script src="js/rs-plugin/videojs/video.js"></script>

<!-- jquery ui -->
<script src="js/jqueryui/jquery-ui.js"></script>
<!-- end jquery ui -->
<script type="text/javascript" language="javascript" src="js/JScript2.js"></script>
<!-- Modules -->
<script src="js/modules/sliders.js"></script>
<script src="js/modules/ui.js"></script>
<script src="js/modules/retina.js"></script>
<script src="js/animate-numbers.js"></script>
<script src="js/modules/parallax-effect.js"></script>
<script src="js/modules/settings.js"></script>
<script src="js/maps.js"></script>
<script src="js/modules/color-themes.js"></script>
<!-- End Modules -->

<!-- Audio player -->
<script type="text/javascript" src="js/audioplayer-js/jquery.jplayer.min.js"></script>
<script type="text/javascript" src="js/audioplayer-js/jplayer.playlist.min.js"></script>
<script src="js/audioplayer.js"></script>
<!-- end Audio player -->

<!-- radial Progress -->
<script src="js/radial-progress/jquery.easing.1.3.js"></script>
<script src="js/JScript5.js"></script>
<script src="js/radial-progress/radialProgress.js"></script>
<script src="js/JScript4.js"></script>
<!-- end Progress -->

<!-- Google services -->
<script type="text/javascript" src="js/JScript3.js"></script>
<script src="js/google-chart.js"></script>
<!-- end Google services -->
<script src="js/j.placeholder.js"></script>

<!-- Fancybox -->
<script src="js/fancybox/jquery.fancybox.pack.js"></script>
<script src="js/fancybox/jquery.mousewheel.pack.js"></script>
<script src="js/fancybox/jquery.fancybox.custom.js"></script>
<!-- End Fancybox -->
<script src="js/user.js"></script>
<script src="js/timeline.js"></script>
<script src="js/JScript6.js"></script>
<script src="js/markerwithlabel.js"></script>
<script src="js/cookie.js"></script>
<script src="js/JScript7.js"></script>
<script src="js/scrollIt/scrollIt.min.js"></script>
<script src="js/JScript8.js"></script>

    </form>
</body>
</html>
